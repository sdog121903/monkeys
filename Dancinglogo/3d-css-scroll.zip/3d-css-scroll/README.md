# 3D CSS Scroll

A Pen created on CodePen.io. Original URL: [https://codepen.io/shshaw/pen/GRdbZEL](https://codepen.io/shshaw/pen/GRdbZEL).

Change `perspective-origin` on scroll ~using CSS variables.~ now JavaScript free!
https://twitter.com/ivorjetski/status/1583158710121074688
https://twitter.com/Futekov/status/1583163711828611072
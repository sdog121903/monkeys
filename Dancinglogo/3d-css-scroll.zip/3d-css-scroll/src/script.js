// Not necessary anymore.
// let b = document.querySelector("body");
// window.addEventListener("scroll", function (e) {
//   b.style.setProperty("--s", window.scrollY);
// });
